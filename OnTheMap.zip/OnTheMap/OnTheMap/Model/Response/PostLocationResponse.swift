//
//  PostLocationResponse.swift
//  OnTheMap
//
//  Created by Aye Nyein Nyein Su on 19/05/2023.
//

import Foundation

struct PostLocationResponse: Codable {
    let objectId: String
    let createdAt: String
}
